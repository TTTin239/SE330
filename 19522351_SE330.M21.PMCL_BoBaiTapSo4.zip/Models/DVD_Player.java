package Models;

public class DVD_Player extends DVD {

    public DVD_Player() {
        this.setModel("DVD_Player");
    }   
}