package Models;

public class LCD_Television extends TV {

    public LCD_Television() {
        this.setModel("LCD Television");
    }   
}